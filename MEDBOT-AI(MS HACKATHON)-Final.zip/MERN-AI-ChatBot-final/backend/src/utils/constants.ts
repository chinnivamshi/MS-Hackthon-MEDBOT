export const COOKIE_NAME = "auth_token";
