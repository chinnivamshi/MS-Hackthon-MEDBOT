// import { google } from 'googleapis';
// import path from 'path';

// export const configureGeminiAPI = () => {
//   const auth = new google.auth.GoogleAuth({
//     keyFile: path.join(__dirname, 'path-to-your-service-account-file.json'), // Provide the correct path to your service account key file
//     scopes: ['https://www.googleapis.com/auth/cloud-platform'],
//   });

//   const generativeLanguage = google.generativelanguage({
//     version: 'v1beta', // or the specific version you are using
//     auth: auth,
//   });

//   return generativeLanguage;
// };
